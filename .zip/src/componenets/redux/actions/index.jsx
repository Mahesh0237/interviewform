export const userMobile = (mobilenum) => {
    return {
        type: 'user_mobile_num',
        payload: mobilenum
    }
}