import { combineReducers } from "redux"
import { userAuthReducer } from './userAuthMobile';

const rootReducer = combineReducers({
    userAuthReducer
})
export default rootReducer